<?php


include 'functions.php';

$errors = array(); 

$db = OpenCon();



if (isset($_POST['submit'])) {
    // receive all input values from the form
    $username = mysqli_real_escape_string($db, $_POST['user']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
    $comment = mysqli_real_escape_string($db, $_POST['comment']);
  
// by adding (array_push()) corresponding error unto $errors array
if (empty($username)) { array_push($errors, "Username is required"); }
if (empty($email)) { array_push($errors, "Email is required"); }
if (empty($mobile)) { array_push($errors, "Mobile is required"); }
if (empty($comment)) { array_push($errors, "Comment is required"); }
if (count($errors) == 0) {

$sql = "INSERT INTO reach (username, email, contact,comments)
VALUES ('$username', '$email','$mobile','$comment')";
$result = mysqli_query($db, $sql);
}

CloseCon($db);

}


?>