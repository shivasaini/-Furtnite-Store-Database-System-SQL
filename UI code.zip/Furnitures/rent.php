<?php


include 'reachus.php';
?>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=josefin+Sans&dispaly=swap" rel="stylesheet">
</head>
<body>


<nav class="navbar navbar-expand-sm navbar-light bg-light fixed-top justify-content-center">
  <a class="navbar-brand" href="welcome.php">IIIT Furniture store</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
    <!-- <li class="nav-item">
        <a class="nav-link" href="#">SALE</a>
      </li> -->
      <li class="nav-item">
        <a class="nav-link" href="welcome.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="purchase.php">Purchase</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="rent.php">Rent</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-4" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<section class= "my-5">
    <div class= "py-5">
        <h2 class = "text-center">Explore our Rental Furniture range</h2>
    </div>
    <div class="container-fluid">
    <div class= "py-2">
        <h2 class = "text-center">Beds</h2>
    </div>

    <div class= "col-lg-12 col-md-5 col-5">
          
            <p class = "py-3"> A bed is more than just a place to sleep. It's where late night reads, movie marathons, conversations and more happen. All the more reason to search a little for the perfect bed, right? King sized beds , Queen sized beds , single beds , kids beds ... whatever your need is, we've got you covered. Explore beds online and find the one that's perfect for you! Less </p>
         
    </div>

</section>



<section class= "my-5">
    <div class= "py-1">
        <h2 class = "text-center"></h2>
    </div>
    <div class="container-fluid">
      <div class= "row">
          <div class= "col-lg-6 col-md-6 col-12">
            <img src= "furniture_images/db3.jpg" class= "img-fluid aboutimg">
          </div>
          <div class= "col-lg-6 col-md-6 col-12">
            <h2 class = "display-4"></h2>
            <p class = "py-4"> Our Exciting range of beds include Double beds, Single beds, sofa cum beds </p>
            <a href= "bedrent.php" class = "btn btn-success"> Explore More </a>
          </div>
</section>

<section class= "my-3">
    <div class="container-fluid">
    <div class= "py-2">
        <h2 class = "text-center">Tables</h2>
    </div>

    <div class= "col-lg-12 col-md-5 col-5">
          
            <p class = "py-3"> A Table isn’t just where you sit to do your work and have meals. Covered in books during exam season, a dining table set becomes a war room. On bad days, it’s where you find comfort with a friend and a cup of coffee. Sometimes it is just where you dump all the clutter of the day. So, what value seems right when it comes to dining table price </p>
         
    </div>

</section>



<section class= "my-5">
    <div class= "py-4">
        <h2 class = "text-center"></h2>
    </div>
    <div class="container-fluid">
      <div class= "row">
          <div class= "col-lg-6 col-md-6 col-12">
            <img src= "furniture_images/ot1.jpg" class= "img-fluid aboutimg">
          </div>
          <div class= "col-lg-6 col-md-6 col-12">
            <h2 class = "display-4">  </h2>
            <p class = "py-4"> Our Exciting range of Tables include Dining tables, offfice tables and multi-purpose tables </p>
            <a href= "tablerent.php" class = "btn btn-success"> Explore More </a>
          </div>
</section>


<section class= "my-3">
    <div class= "py-1">
        <h2 class = "text-center">Chairs</h2>
    </div>

    <div class= "col-lg-12 col-md-5 col-5">
          
            <p class = "py-3"> A chair is a piece of furniture for one person to sit on. Chairs have a back and four legs. ... The person who is the chair of a committee or meeting is the person in charge of it. </p>
         
    </div>

</section>



<section class= "my-5">
    <div class= "py-4">
        <h2 class = "text-center"></h2>
    </div>
    <div class="container-fluid">
      <div class= "row">
          <div class= "col-lg-6 col-md-6 col-12">
            <img src= "furniture_images/cc2.jpg" class= "img-fluid aboutimg">
          </div>
          <div class= "col-lg-6 col-md-6 col-12">
            <h2 class = "display-4"></h2>
            <p class = "py-4"> Our Exciting range of Chairs include Dining Chairs, Office Chairs and many more for your needs. </p>
            <a href= "chairrent.php" class = "btn btn-success"> Explore More </a>
          </div>
</section>


<section class= "my-4">
    <div class= "py-5">
        <h2 class = "text-center">Reach Us</h2>
    </div>
    <div class="w-50 m-auto">
      <form action="rent.php" method="post">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="user" autocomplete="off" class="form-control"> 
        </div>

        <div class="form-group">
            <label>Email Id</label>
            <input type="text" name="email" autocomplete="off" class="form-control"> 
        </div>

        <div class="form-group">
            <label>Contact No.</label>
            <input type="tel" name="mobile" autocomplete="off" class="form-control"> 
        </div>

        <div class="form-group">
            <label>Any Comments</label>
            <textarea name="comment" class="form-control">
            </textarea> 
        </div>
        <button type="submit" class="btn  btn-success" name="submit"> Submit </button>
      </form>
    </div>

</section>

<footer>
    <p class="p-3 bg-dark text-white text-center "> @Group-2 DBMS project - FurnitureStore </p> 

</footer>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</body>
</html>