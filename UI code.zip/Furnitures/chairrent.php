<?php
 include 'functions.php';

       
 $con = OpenCon();
 
    if (isset($_POST["add"])){
        if (isset($_SESSION["cart"])){
            $item_array_id = array_column($_SESSION["cart"],"product_id");
            if (!in_array($_GET["id"],$item_array_id)){
                $count = count($_SESSION["cart"]);
                $item_array = array(
                    'product_id' => $_GET["id"],
                    'item_name' => $_POST["hidden_name"],
                    'product_price' => $_POST["hidden_price"],
                    'item_quantity' => $_POST["quantity"],
                );
                $_SESSION["cart"][$count] = $item_array;
                echo '<script>window.location="Cart1.php"</script>';
            }else{
                echo '<script>alert("Product is already Added to Cart")</script>';
                echo '<script>window.location="Cart1.php"</script>';
            }
        }else{
            $item_array = array(
                'product_id' => $_GET["id"],
                'item_name' => $_POST["hidden_name"],
                'product_price' => $_POST["hidden_price"],
                'item_quantity' => $_POST["quantity"],
            );
            $_SESSION["cart"][0] = $item_array;
        }
    }

    if (isset($_GET["action"])){
        if ($_GET["action"] == "delete"){
            
                if ($value["product_id"] == $_GET["id"]){
                    unset($_SESSION["cart"][$keys]);
                    echo '<script>alert("Product has been Removed...!")</script>';
                    echo '<script>window.location="Cart1.php"</script>';
                }
            }
        }
    
?>

<html>
<head>
    <title></title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=josefin+Sans&dispaly=swap" rel="stylesheet">

  <script data-require="jquery@3.1.1" data-semver="3.1.1" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="style.css" />
    <script src="script.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <a class="navbar-brand" href="welcome.php">IIIT Furniture store</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
   
      </li>
      <li class="nav-item">
        <a class="nav-link" href="welcome.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="purchase.php">Purchase</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="rent.php">Rent</a>
      </li>
      
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>



<section class= "my-5">
    <div class= "py-4">
        <h2 class = "text-center">All Chairs</h2>
    </div>

    <div class= "col-lg-12 col-md-5 col-5">
        
            <p class = "py-3"> A chair is a piece of furniture for one person to sit on. Chairs have a back and four legs. ... The person who is the chair of a committee or meeting is the person in charge of it. </p>
        
    </div>
    <div class="container-fluid">
      <div class= "row">
          <div class= "col-lg-6 col-md-6 col-12">
            <img src= "furniture_images/cc3.jpg" class= "img-fluid aboutimg">
          </div>
          <div class= "col-lg-6 col-md-6 col-12">
            <h2 class = "display-4"> Chairs</h2>
            <p class = "py-4"> Our Exciting range of Chairs include Dining Chairs, Office Chairs and many more for your needs. </p>
            <a href= "about.php" class = "btn btn-success"> </a>
          </div>

  
    
</section>

<section class= "my-5">
    <div class= "py-5">
        <h2 id="Singlebeds" class = "text-center">Explore by Categories </h2>
    </div>

    <div>
      <h3 class="p-3 bg-dark text-white "> Arm Chair </h3> 
    </div>

    <div class= "Container-fluid">
      <div class= "row">
    
        <?php
      
            $query = "SELECT R_name, RP_Price, RP_name,RP_ID FROM rentproduct,renter where rentproduct.R_ID = renter.R_ID AND RP_name= 'Arm Chair' LIMIT 3 ";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {

                    ?>
                    <div class="col-lg-4 col-md-4 col-12">

                        <form method="post" action="Cart1.php?action=add&id=<?php echo $row["R_name"]; ?>">

                            <div class="product">
                            <img  class="card-img-top" src="furniture_images/oc3.jpg" alt="Card image" class=\"img-fluid card-img-top\">
                                 <h5 class="text-info"><?php echo $row["R_name"]; ?></h5> 
                                <h5 class="text-danger"><?php echo $row["RP_Price"]; ?></h5>
                                <input type="text" name="quantity" class="form-control" value="1">
                                <input type="hidden" name="hidden_name" value="<?php echo $row["RP_name"]; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row["RP_Price"]; ?>">
                                <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-success"
                                       value="Add to Cart">
                            </div>
                        </form>
                    </div>
                    <?php
                }
            }
        ?>
</section>

<section class= "my-5">
    <div>
      <h3 class="p-3 bg-dark text-white "> Cafe Chair </h3> 
    </div>

    <div class= "Container-fluid">
      <div class= "row">
    
        <?php
      
            $query = "SELECT R_name, RP_Price, RP_name,RP_ID FROM rentproduct,renter where rentproduct.R_ID = renter.R_ID AND RP_name = 'Cafe Chair' LIMIT 3 ";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {

                    ?>
                    <div class="col-lg-4 col-md-4 col-12">

                        <form method="post" action="Cart1.php?action=add&id=<?php echo $row["R_name"]; ?>">

                            <div class="product">
                            <img  class="card-img-top" src="furniture_images/cc2.jpg" alt="Card image" class=\"img-fluid card-img-top\">
                                <h5 class="text-info"><?php echo $row["R_name"]; ?></h5> 
                                <h5 class="text-danger"><?php echo $row["RP_Price"]; ?></h5>
                                <input type="text" name="quantity" class="form-control" value="1">
                                <input type="hidden" name="hidden_name" value="<?php echo $row["RP_name"]; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row["RP_Price"]; ?>">
                                <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-success"
                                       value="Add to Cart">
                            </div>
                        </form>
                    </div>
                    <?php
                }
            }
        ?>
</section>

<section class= "my-5">
    
    <div>
      <h3 class="p-3 bg-dark text-white ">Rocking Chair</h3> 
    </div>

    <div class= "Container-fluid">
      <div class= "row">
    
        <?php
      
            $query = "SELECT R_name, RP_Price, RP_name,RP_ID FROM rentproduct,renter where rentproduct.R_ID = renter.R_ID AND RP_name=' Rocking Chair' LIMIT 3 ";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {

                    ?>
                    <div class="col-lg-4 col-md-4 col-12">

                        <form method="post" action="Cart1.php?action=add&id=<?php echo $row["R_name"]; ?>">

                            <div class="product">
                            <img  class="card-img-top" src="furniture_images/rc2.jpeg" alt="Card image" class=\"img-fluid card-img-top\">
                                 <h5 class="text-info"><?php echo $row["R_name"]; ?></h5> 
                                <h5 class="text-danger"><?php echo $row["RP_Price"]; ?></h5>
                                <input type="text" name="quantity" class="form-control" value="1">
                                <input type="hidden" name="hidden_name" value="<?php echo $row["RP_name"]; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row["RP_Price"]; ?>">
                                <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-success"
                                       value="Add to Cart">
                            </div>
                        </form>
                    </div>
                    <?php
                }
            }
        ?>
</section>






<footer>
    <p class="p-3 bg-dark text-white text-center "> @Group-2 DBMS project - FurnitureStore </p> 

</footer>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</body>
</html>