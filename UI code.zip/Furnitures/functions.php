<?php
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "again";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }

 function getrentername( $ID){

    $con = OpenCon();
    $query = "SELECT S_name from Seller S1, Saleproducts S2 where S1.S_ID= S2.S_ID and S2.SP_ID =ID";
$result = mysqli_query($con,$query);
    return $result;

 }
   
?>