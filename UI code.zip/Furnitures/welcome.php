<?php


include 'reachus.php';
?>

<html>
<head>
    <title></title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=josefin+Sans&dispaly=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <a class="navbar-brand" href="welcome.php">IIIT Furniture store</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <!-- // <a class="nav-link" href="#">SALE</a>
     // </li> -->
      <li class="nav-item active">
        <a class="nav-link" href="welcome.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="purchase.php">Purchase</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="rent.php">Rent</a>
      </li>
      <!-- <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Categories
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="bedpurchase.php">Beds</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Tables</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Chairs</a>
        </div>
      </li> -->
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div id="demo"  class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item">
      <img src="furniture_images/scb1.jpg" alt="Los Angeles"  >
      <div class="carousel-caption">
        <h3></h3>
        <p></p>
      </div>   
    </div>
    <div class="carousel-item active">
      <img src="Furniture_images/sb1.jpg" alt="Chicago"  >
      <div class="carousel-caption">
        <h3></h3>
        <p></p>
      </div>   
    </div>
    <div class="carousel-item ">
      <img src="Furniture_images/db3.jpg" alt="New York" >
      <div class="carousel-caption">
        <h3></h3>
        <p></p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>



<section class= "my-4">
    <div class= "py-5">
        <h2 class = "text-center">Explore by Categories</h2>
    </div>

    <div>
      <h3 class="p-3 bg-dark text-white "> Beds </h3> 
    </div>

    <div class= "container-fluid">
      <div class= "row d-md-flex align-items-stretch ">
        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/sb1.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Single Beds</h4>
             <p class="card-text"></p>
              <a href="bedpurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="bedrent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>
    
        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/db1.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Double Beds</h4>
             <p class="card-text"></p>
              <a href="bedpurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="bedrent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>

        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/Scb1.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Sofa cum beds</h4>
             <p class="card-text"></p>
              <a href="bedpurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="bedrent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>
      </div>
    </div>    
</section>

<section class= "my-5">
    <div>
      <h3 class="p-3 bg-dark text-white "> Tables </h3> 
    </div>

    <div class= "Container-fluid">
      <div class= "row">
        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/ot1.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Office Tables</h4>
             <p class="card-text"></p>
              <a href="tablepurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="tablerent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>
    
        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/din3.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Dining Tables</h4>
             <p class="card-text"></p>
              <a href="tablepurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="tablerent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>

        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/dr2.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Dressing Tables</h4>
             <p class="card-text"></p>
              <a href="tablepurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="tablerent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>
      </div>
    </div>    
</section>

<section class= "my-5">
    
    <div>
      <h3 class="p-3 bg-dark text-white "> Chairs </h3> 
    </div>

    <div class= "Container-fluid">
      <div class= "row">
        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/oc2.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Arm Chairs</h4>
             <p class="card-text"></p>
              <a href="chairpurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="chairrent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>
    
        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/cc1.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Cafe Chairs</h4>
             <p class="card-text"></p>
              <a href="chairpurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="chairrent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>

        <div class = "col-lg-4 col-md-4 col-12">
          <div class="card">
            <img class="card-img-top" style="height: 250px; width:auto;" src="furniture_images/rc1.jpg" alt="Card image">
            <div class="card-body">
             <h4 class="card-title">Rocking Chairs</h4>
             <p class="card-text"></p>
              <a href="chairpurchase.php" class="btn btn-primary ">Purchase</a>
              <a href="chairrent.php" class="btn btn-success ">Rent</a>
            </div>
          </div>
        </div>
      </div>
    </div>    
</section>



<section class= "my-4">
    <div class= "py-5">
        <h2 class = "text-center">Reach Us</h2>
    </div>

    <div class="w-50 m-auto">
      <form action="welcome" method="post">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="user" autocomplete="off" class="form-control"> 
        </div>

        <div class="form-group">
            <label>Email Id</label>
            <input type="text" name="email" autocomplete="off" class="form-control"> 
        </div>

        <div class="form-group">
            <label>Contact No.</label>
            <input type="tel" name="mobile" autocomplete="off" class="form-control"> 
        </div>

        <div class="form-group">
            <label>Any Comments</label>
            <textarea name="comment" class="form-control">
            </textarea> 
        </div>
        <button type="submit" class="btn  btn-success" name="submit"> Submit </button>
      </form>
    </div>

</section>

<footer>
    <p class="p-3 bg-dark text-white text-center "> @Group-2 DBMS project - FurnitureStore </p> 

</footer>











    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</body>
</html>